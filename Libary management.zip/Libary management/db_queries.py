"""
db_queries.py
------------------------------------------------
File riêng chứa toàn bộ phần kết nối và truy vấn CSDL SQL Server (LibraryManagement)
cho ứng dụng Thư Viện Xanh. Tách riêng khỏi file giao diện (thu_vien_xanh_app.py)
để dễ bảo trì: nếu cần đổi thông tin kết nối hoặc sửa câu truy vấn, chỉ cần sửa
trong file này.

Yêu cầu thư viện: pyodbc (pip install pyodbc)

Kết nối database:
    Thông tin kết nối nằm trong DB_CONFIG (server=DESKTOP-GJE5BU3,
    database=LibraryManagement, uid=sa, pwd=123).
    Hàm fetch_books_by_category() join bảng Books + Author và lọc theo
    categoryId (C001=Tiểu Thuyết, C002=Văn Học, C003=Truyện Tranh, C004=Kinh Dị)
    đúng theo schema trong file LibraryManagement.sql.
    Nếu không kết nối được (thiếu pyodbc, sai driver, server tắt, v.v...),
    hàm sẽ trả về dữ liệu mẫu (fallback) được truyền vào, để giao diện vẫn chạy.
"""

# pyodbc dùng để kết nối SQL Server. Nếu chưa cài (pip install pyodbc) hoặc
# không có driver, chương trình vẫn chạy được bằng dữ liệu mẫu (fallback).
try:
    import pyodbc
    PYODBC_AVAILABLE = True
except ImportError:
    PYODBC_AVAILABLE = False

# ----------------------------------------------------------------------------
# KẾT NỐI DATABASE (SQL Server - LibraryManagement)
# ----------------------------------------------------------------------------
DB_CONFIG = {
    "driver": "{SQL Server}",
    "server": "DESKTOP-GJE5BU3",
    "database": "LibraryManagement",
    "uid": "sa",
    "pwd": "123",
}


def get_db_connection():
    """Tạo kết nối tới SQL Server dựa trên DB_CONFIG."""
    conn_str = (
        f"DRIVER={DB_CONFIG['driver']};"
        f"SERVER={DB_CONFIG['server']};"
        f"DATABASE={DB_CONFIG['database']};"
        f"UID={DB_CONFIG['uid']};"
        f"PWD={DB_CONFIG['pwd']}"
    )
    return pyodbc.connect(conn_str)


def fetch_books_by_category(category_id, fallback):
    """
    Lấy danh sách sách theo thể loại từ CSDL LibraryManagement.

    category_id: mã categoryId trong bảng Category:
        C001 = Tiểu Thuyết, C002 = Văn Học, C003 = Truyện Tranh, C004 = Kinh Dị

    Join 2 bảng Books + Author theo đúng schema trong LibraryManagement.sql:
        Books(isbn, categoryId, authorId, title, publisher, publishYear, imageUrl, description)
        Author(authorId, authorName, imageUrl, biography)

    Nếu không cài pyodbc, không kết nối được, hoặc câu truy vấn lỗi/không có
    dòng nào khớp, hàm sẽ trả về dữ liệu mẫu (fallback) để giao diện vẫn
    hiển thị bình thường thay vì bị crash.
    """
    if not PYODBC_AVAILABLE:
        print("[Cảnh báo] Chưa cài pyodbc (pip install pyodbc) -> dùng dữ liệu mẫu.")
        return fallback

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT b.imageUrl, b.title, a.authorName, b.publishYear
            FROM Books b
            JOIN Author a ON b.authorId = a.authorId
            WHERE b.categoryId = ?
            ORDER BY b.title
            """,
            category_id,
        )
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

        if not rows:
            return fallback

        books = []
        for image_url, title, author_name, publish_year in rows:
            books.append({
                "img": (image_url or "").strip(),
                "title": (title or "").strip(),
                "author": (author_name or "").strip(),
                "year": f"({publish_year})" if publish_year else "",
            })
        return books

    except Exception as e:
        print(f"[Cảnh báo] Lỗi khi lấy dữ liệu thể loại '{category_id}' từ CSDL: {e}")
        print("=> Đang dùng dữ liệu mẫu (fallback) để giao diện vẫn chạy được.")
        return fallback
